﻿namespace Bulky.DataAccess
{
    public class Class1
    {

    }
}
