﻿namespace Bulky.Models
{
    public class Class1
    {

    }
}
